function showTab(tab) {
  document.querySelectorAll('.tab').forEach(el => el.classList.add('hidden'));
  document.getElementById(tab).classList.remove('hidden');
}

document.getElementById('theme-toggle').addEventListener('click', () => {
  document.body.classList.toggle('dark');
});

document.getElementById('clear-chat').addEventListener('click', () => {
  document.getElementById('chat-box').innerHTML = '';
});

async function sendMessage() {
  let input = document.getElementById('user-input');
  let message = input.value.trim();
  if (!message) return;
  appendMessage(message, 'user');
  input.value = '';

  appendMessage('Typing...', 'bot', true);

  let response = await fetch('/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message })
  });
  let data = await response.json();

  removeTyping();
  appendMessage(data.reply, 'bot');
}

async function generateImage() {
  let input = document.getElementById('image-input');
  let prompt = input.value.trim();
  if (!prompt) return;
  document.getElementById('image-box').innerHTML = '<p>Generating...</p>';
  let response = await fetch('/image', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt })
  });
  let data = await response.json();
  document.getElementById('image-box').innerHTML = '<img src="' + data.url + '" alt="Generated Image" style="max-width:100%; border-radius:10px;">';
}

function appendMessage(text, sender, typing=false) {
  let box = document.getElementById('chat-box');
  let msg = document.createElement('div');
  msg.className = 'message ' + sender;
  msg.textContent = text;
  if (typing) msg.classList.add('typing');
  box.appendChild(msg);
  box.scrollTop = box.scrollHeight;
}

function removeTyping() {
  document.querySelectorAll('.typing').forEach(el => el.remove());
}