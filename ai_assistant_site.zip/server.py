from flask import Flask, request, jsonify, render_template
import openai, os

app = Flask(__name__)

openai.api_key = os.getenv("OPENAI_API_KEY")

@app.route('/')
def home():
    return app.send_static_file('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    data = request.get_json()
    user_message = data.get("message", "")
    try:
        response = openai.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": user_message}]
        )
        reply = response.choices[0].message.content
        return jsonify({"reply": reply})
    except Exception as e:
        return jsonify({"reply": "⚠️ Error: " + str(e)})

@app.route('/image', methods=['POST'])
def image():
    data = request.get_json()
    prompt = data.get("prompt", "")
    try:
        response = openai.images.generate(
            model="gpt-image-1",
            prompt=prompt,
            size="512x512"
        )
        url = response.data[0].url
        return jsonify({"url": url})
    except Exception as e:
        return jsonify({"url": ""})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
