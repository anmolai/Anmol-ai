# 🤖 AI Chatbot & Image Generator

This project is a simple **AI-powered chatbot and image generator website** built with Flask and OpenAI.

## 🚀 Features
- 💬 Chat with AI (GPT-4o-mini)
- 🖼 Generate AI images from text prompts
- 🌙 Dark/Light theme toggle
- 📱 Responsive design (works on mobile & desktop)
- 🧹 Clear chat button
- ⏳ Typing animation for AI responses

## 🛠 Setup
1. Clone the repo or upload files to Render
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Set your OpenAI API key:
   ```bash
   export OPENAI_API_KEY=your_api_key_here
   ```
4. Run locally:
   ```bash
   python server.py
   ```
5. Deploy to Render (use Procfile for startup)

## 📌 Deployment on Render
- Add environment variable: `OPENAI_API_KEY`
- Use build command: `pip install -r requirements.txt`
- Use start command: `gunicorn server:app`

Enjoy your AI assistant 🎉
